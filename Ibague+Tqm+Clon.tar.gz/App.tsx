import { useState, useEffect, useRef } from 'react';

type Channel = {
  id: string;
  name: string;
  category: 'Deportes' | 'Cine' | 'Entretenimiento' | 'Música';
  initials: string;
  gradient: string;
  embedUrl: string;
};

const CHANNELS: Channel[] = [
  { id: 'fifa', name: 'FIFA Plus', category: 'Deportes', initials: 'FIFA+', gradient: 'from-[#0a1f3f] to-[#123a6b]', embedUrl: 'https://www.parsatv.com/embed.php?name=FIFA-Plus&auto=false' },
  { id: 'mlb', name: 'MLB TV', category: 'Deportes', initials: 'MLB', gradient: 'from-[#0f1a2e] to-[#1a2f5a]', embedUrl: 'https://www.parsatv.com/embed.php?name=MLB-TV&auto=false' },
  { id: 'tennis', name: 'Tennis Channel', category: 'Deportes', initials: 'TC', gradient: 'from-[#0a2a1a] to-[#14532d]', embedUrl: 'https://www.parsatv.com/embed.php?name=Tennis-Channel&auto=false' },
  { id: 'hbo-latino', name: 'HBO Latino', category: 'Cine', initials: 'HBO L', gradient: 'from-[#1a0a1a] to-[#3a0a2e]', embedUrl: 'https://trend48.st/live-tv?ch=hbolatino-usa' },
  { id: 'fox1', name: 'Fox Sports 1', category: 'Deportes', initials: 'FS1', gradient: 'from-[#0a1020] to-[#1e2d5a]', embedUrl: 'https://trend48.st/live-tv?ch=fox-sports-1' },
  { id: 'hbo-movies', name: 'HBO Movies', category: 'Cine', initials: 'HBO M', gradient: 'from-[#111111] to-[#2a2a2a]', embedUrl: 'https://trend48.st/live-tv?ch=hbomovies-usa' },
  { id: 'nba', name: 'NBA TV', category: 'Deportes', initials: 'NBA', gradient: 'from-[#1a0f0a] to-[#4a1f0a]', embedUrl: 'https://trend48.st/live-tv?ch=nbatv-usa' },
  { id: 'pokergo', name: 'PokerGO', category: 'Deportes', initials: 'PGO', gradient: 'from-[#0a0a0a] to-[#1f1a0a]', embedUrl: 'https://www.parsatv.com/embed.php?name=PokerGO&auto=false' },
  { id: 'bravo', name: 'Bravo', category: 'Entretenimiento', initials: 'BRAVO', gradient: 'from-[#1a0a1f] to-[#3a1a4a]', embedUrl: 'https://trend48.st/live-tv?ch=bravo-usa' },
  { id: 'axs', name: 'AXS TV', category: 'Música', initials: 'AXS', gradient: 'from-[#0a0a0a] to-[#222222]', embedUrl: 'https://trend48.st/live-tv?ch=axs-usa' },
  { id: 'real-madrid', name: 'Real Madrid TV', category: 'Deportes', initials: 'RMTV', gradient: 'from-[#f5f5f5] to-[#d4d4d8]', embedUrl: 'https://www.parsatv.com/embed.php?name=Real-Madrid-TV&auto=false' },
  { id: 'kozoom', name: 'Kozoom TV', category: 'Deportes', initials: 'KZ', gradient: 'from-[#0a1a0a] to-[#1a3a1a]', embedUrl: 'https://www.parsatv.com/embed.php?name=Kozoom-TV&auto=false' },
  { id: 'strongman', name: 'Strongman', category: 'Deportes', initials: 'STRONG', gradient: 'from-[#1a0a0a] to-[#4a0a0a]', embedUrl: 'https://www.parsatv.com/embed.php?name=Strongman&auto=false' },
  { id: 'redbull', name: 'Red Bull TV', category: 'Deportes', initials: 'RB TV', gradient: 'from-[#0a1220] to-[#1e293b]', embedUrl: 'https://www.parsatv.com/embed.php?name=Red-Bull-TV&auto=false' },
  { id: 'miami', name: 'Miami TV Latino', category: 'Entretenimiento', initials: 'MTV L', gradient: 'from-[#0a1a2a] to-[#123a5a]', embedUrl: 'https://www.parsatv.com/embed.php?name=Miami-TV-Latino&auto=false' },
  { id: 'telemundo', name: 'Telemundo Accion', category: 'Cine', initials: 'T ACC', gradient: 'from-[#1a0a0a] to-[#3a0a0a]', embedUrl: 'https://www.parsatv.com/embed.php?name=Telemundo-Accion&auto=false' },
  { id: 'cine-sony', name: 'Cine Sony', category: 'Cine', initials: 'SONY', gradient: 'from-[#0a0a0a] to-[#262626]', embedUrl: 'https://www.parsatv.com/embed.php?name=Cine-Sony&auto=false' },
  { id: 'deluxe', name: 'Deluxe Music', category: 'Música', initials: 'DELUXE', gradient: 'from-[#1a1a0a] to-[#3a2a0a]', embedUrl: 'https://www.parsatv.com/embed.php?name=Deluxe-Music&auto=false' },
  { id: 'retro', name: 'Retro Music', category: 'Música', initials: 'RETRO', gradient: 'from-[#1f0a1a] to-[#4a1a3a]', embedUrl: 'https://www.parsatv.com/embed.php?name=Retro-Music&auto=false' },
  { id: 'deejay', name: 'Deejay TV', category: 'Música', initials: 'DEEJAY', gradient: 'from-[#0a0a0a] to-[#1a1a1a]', embedUrl: 'https://www.parsatv.com/embed.php?name=Deejay-TV&auto=false' },
  { id: 'vevo', name: 'Vevo TV', category: 'Música', initials: 'vevo', gradient: 'from-[#0a0a0a] to-[#1f1f1f]', embedUrl: 'https://www.parsatv.com/embed.php?name=Vevo-TV&auto=false' },
  { id: 'fite', name: 'FITE 247', category: 'Deportes', initials: 'FITE', gradient: 'from-[#0a0a0a] to-[#1a0a0a]', embedUrl: 'https://www.parsatv.com/embed.php?name=FITE-247&auto=false' },
  { id: 'fxm', name: 'FXM', category: 'Cine', initials: 'FXM', gradient: 'from-[#0a0a0a] to-[#222222]', embedUrl: 'https://trend48.st/live-tv?ch=fxm-usa' },
  { id: 'ae', name: 'A&E', category: 'Entretenimiento', initials: 'A&E', gradient: 'from-[#111111] to-[#2a2a2a]', embedUrl: 'https://trend48.st/live-tv?ch=ae-usa' },
  { id: 'amc', name: 'AMC', category: 'Cine', initials: 'AMC', gradient: 'from-[#0a0a0a] to-[#1a1a1a]', embedUrl: 'https://trend48.st/live-tv?ch=amc-usa' },
];

const CATEGORIES = ['Todos', 'Deportes', 'Cine', 'Entretenimiento', 'Música'] as const;
const QUICK_FILTERS = ['Todos', 'Deportes', 'Cine'] as const;

const RADIOS = [
  { id: '01', name: 'Emisora 01', tag: 'Radio en vivo · Zeno', color: '#ff1a2e' },
  { id: '02', name: 'Emisora 02', tag: 'Radio en vivo · Zeno', color: '#7c3aed' },
  { id: '03', name: 'Emisora 03', tag: 'Radio en vivo · Zeno', color: '#06b6d4' },
  { id: '04', name: 'Emisora 04', tag: 'Radio en vivo · Zeno', color: '#eab308' },
];

export default function App() {
  const [activeCat, setActiveCat] = useState<(typeof CATEGORIES)[number]>('Todos');
  const [selected, setSelected] = useState<Channel | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [playingRadio, setPlayingRadio] = useState<string | null>(null);
  const [isRadioPlaying, setIsRadioPlaying] = useState(false);
  const [progress, setProgress] = useState(34);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const filtered = activeCat === 'Todos' ? CHANNELS : CHANNELS.filter(c => c.category === activeCat);

  // Meta viewport + theme-color: width=device-width, initial-scale=1, viewport-fit=cover, user-scalable=no
  useEffect(() => {
    let viewport = document.querySelector('meta[name="viewport"]') as HTMLMetaElement | null;
    if (!viewport) {
      viewport = document.createElement('meta');
      viewport.setAttribute('name', 'viewport');
      document.head.appendChild(viewport);
    }
    viewport.setAttribute('content', 'width=device-width, initial-scale=1, viewport-fit=cover, user-scalable=no');
    let theme = document.querySelector('meta[name="theme-color"]') as HTMLMetaElement | null;
    if (!theme) {
      theme = document.createElement('meta');
      theme.setAttribute('name', 'theme-color');
      document.head.appendChild(theme);
    }
    theme.setAttribute('content', '#070707');
  }, []);

  useEffect(() => {
    if (!isRadioPlaying) return;
    const id = setInterval(() => {
      setProgress(p => (p >= 100 ? 0 : p + 0.12));
    }, 120);
    return () => clearInterval(id);
  }, [isRadioPlaying]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeModal();
    };
    if (showModal) window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [showModal]);

  // Bloquear scroll del fondo cuando el modal está abierto
  useEffect(() => {
    document.body.style.overflow = showModal ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [showModal]);

  const openChannel = (ch: Channel) => {
    setSelected(ch);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setTimeout(() => setSelected(null), 240);
  };

  const toggleRadio = (id: string) => {
    if (playingRadio === id && isRadioPlaying) {
      setIsRadioPlaying(false);
    } else {
      setPlayingRadio(id);
      setIsRadioPlaying(true);
      setProgress(Math.random() * 55 + 12);
    }
  };

  const goToChannels = (cat: (typeof CATEGORIES)[number]) => {
    setActiveCat(cat);
    document.getElementById('canales')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const goTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

  return (
    <div
      data-safe-area-inset-root
      className="min-h-screen w-full bg-[#070707] text-white antialiased overflow-x-clip"
      style={{ boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)' }}
    >
      {/* HEADER STICKY COMPACTO */}
      <header
        data-safe-area-sticky-top
        className="sticky z-30 border-b border-white/[0.06] backdrop-blur-2xl"
        style={{ top: 'var(--safe-area-inset-top)', background: 'rgba(7,7,7,0.92)' }}
      >
        <div className="mx-auto max-w-[1440px] flex min-h-[56px] md:h-[64px] items-center justify-between gap-2 px-4 sm:px-5 md:px-8 lg:px-10 py-2 md:py-0">
          <div className="flex items-center gap-3 md:gap-8 min-w-0">
            <button onClick={goTop} className="flex items-baseline gap-[2px] select-none shrink-0 text-left min-h-[36px] items-center" aria-label="Ir arriba">
              <span className="text-[20px] md:text-[24px] font-black tracking-[-0.02em] font-display leading-none">ibagué</span>
              <span className="text-[10px] md:text-[12px] font-bold tracking-[0.22em] ml-[5px] opacity-90 leading-none">T.Q.M.</span>
              <span className="ml-1.5 h-[4px] w-[4px] rounded-full bg-[#ff1a2e] inline-block translate-y-[-8px]" />
            </button>
            <p className="hidden lg:block text-[11px] text-white/40 leading-tight">TV y música<br />en vivo · Ibagué</p>
            <nav className="hidden md:flex items-center gap-1" aria-label="Categorías">
              {CATEGORIES.map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveCat(cat)}
                  className={`min-h-[36px] px-3.5 rounded-full text-[13px] font-medium transition-all ${
                    activeCat === cat ? 'bg-white text-black' : 'text-white/60 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </nav>
          </div>

          <div className="flex items-center gap-2 md:gap-3 shrink-0">
            <a
              href="https://ibaguetequiero.lovable.app/"
              target="_blank"
              rel="noopener"
              className="inline-flex min-h-[36px] items-center gap-2 text-[12px] font-medium text-white/50 hover:text-white transition-colors border border-white/10 rounded-full px-3 py-1.5"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#ff1a2e] animate-pulse shrink-0" />
              <span className="hidden sm:inline">Fuente original</span>
              <span className="sm:hidden">Fuente</span>
            </a>
            <div className="hidden sm:flex items-center gap-2 text-[11px] text-white/40">
              <span className="h-px w-6 bg-white/20" />
              <span className="uppercase tracking-[0.18em]">En vivo 24/7</span>
            </div>
            <div className="h-9 w-9 min-h-[36px] min-w-[36px] rounded-full bg-white text-black grid place-items-center font-bold text-[12px] shrink-0">I</div>
          </div>
        </div>

        {/* FILTROS MÓVIL: scroll táctil + snap, sin scrollbar */}
        <div className="md:hidden border-t border-white/[0.06]">
          <div className="filter-scroll flex gap-2 px-4 py-2.5 overflow-x-auto no-scrollbar snap-x snap-mandatory">
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCat(cat)}
                className={`snap-start shrink-0 whitespace-nowrap min-h-[36px] px-4 rounded-full text-[13px] font-medium transition ${
                  activeCat === cat ? 'bg-white text-black' : 'bg-white/10 text-white/70 active:bg-white/20'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1440px] px-4 sm:px-5 md:px-8 lg:px-10 pb-24 md:pb-0">
        {/* HERO */}
        <section className="pt-8 md:pt-14 pb-7 md:pb-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-5 md:gap-6">
            <div className="min-w-0">
              <div className="flex items-start gap-3 mb-3">
                <h1 className="font-display font-[800] leading-[0.9] tracking-[-0.04em] text-balance" style={{ fontSize: 'clamp(38px, 11vw, 84px)' }}>
                  Enciende la
                  <br />
                  pantalla
                </h1>
                <div className="hidden md:flex h-[48px] w-[48px] lg:h-[64px] lg:w-[64px] rounded-full border border-white/20 items-center justify-center -rotate-12 ml-2 shrink-0">
                  <span className="text-[22px]">↗</span>
                </div>
              </div>
              <div className="flex items-center gap-2 text-white/50 text-[12px] md:text-[13px] uppercase tracking-[0.2em] font-medium">
                <span className="h-px w-8 bg-white/20 shrink-0" />
                Televisión curada · Ibagué
              </div>
            </div>

            <div className="flex items-start gap-5 md:text-right shrink-0">
              <div className="md:text-right">
                <div className="flex items-center md:justify-end gap-2">
                  <span className="text-[38px] md:text-[56px] font-black leading-none tracking-[-0.04em] font-display">{filtered.length}</span>
                  <span className="text-[12px] md:text-[13px] leading-[1.1] text-white/60 uppercase tracking-wide">
                    canales
                    <br />
                    <span className="inline-flex items-center gap-1">↗ <span className="w-2 h-2 bg-[#ff1a2e] rounded-full live-dot inline-block" /></span>
                  </span>
                </div>
                <p className="mt-2 text-[13px] text-white/40 max-w-[280px] md:ml-auto">
                  Señal estable, sin registro. Zapping infinito tipo cable premium con reproductores reales validados.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* GRID CANALES: 2 móvil / 3 tablet / 4 PC / 5 grande */}
        <section id="canales" className="pb-12 md:pb-16">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 min-[1400px]:grid-cols-5 gap-2.5 sm:gap-3 md:gap-4">
            {filtered.map(ch => (
              <button
                key={ch.id}
                onClick={() => openChannel(ch)}
                className="channel-card group text-left rounded-[16px] md:rounded-[20px] bg-[#121212] border border-white/[0.07] overflow-hidden card-hover focus:outline-none focus-visible:ring-2 focus-visible:ring-white/30 active:scale-[0.97] transition-transform"
                aria-label={`Ver ${ch.name}`}
              >
                <div className={`relative aspect-[16/10] overflow-hidden bg-gradient-to-br ${ch.gradient}`}>
                  <div className="absolute inset-0 bg-black/20" />
                  <div className="absolute inset-0 grid place-items-center px-2">
                    <span className="font-black tracking-[-0.03em] text-white drop-shadow-[0_2px_12px_rgba(0,0,0,0.6)] text-[17px] sm:text-[20px] md:text-[22px] leading-none font-display text-center break-words">
                      {ch.initials}
                    </span>
                  </div>
                  <div className="absolute left-2 top-2 flex items-center gap-2">
                    <span className="inline-flex items-center gap-1 rounded-full bg-[#ff1a2e] px-1.5 sm:px-2 py-[3px] text-[8px] sm:text-[9px] font-bold tracking-[0.08em] text-white">
                      <span className="h-[5px] w-[5px] rounded-full bg-white live-dot" />
                      EN VIVO
                    </span>
                  </div>
                  <div className="absolute inset-x-0 bottom-0 h-[54%] bg-gradient-to-t from-black/70 to-transparent pointer-events-none" />
                  {/* Play siempre visible en táctil, hover en desktop */}
                  <div className="absolute inset-0 grid place-items-center">
                    <div className="h-10 w-10 md:h-11 md:w-11 rounded-full bg-white text-black grid place-items-center shadow-xl md:opacity-0 md:group-hover:opacity-100 transition-opacity duration-300">
                      <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor" aria-hidden="true"><path d="M3 2.5 L11 7 L3 11.5 Z" /></svg>
                    </div>
                  </div>
                </div>
                <div className="px-3 md:px-3.5 py-3 md:py-3.5">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-[13px] md:text-[14px] font-bold leading-tight tracking-[-0.01em] truncate">{ch.name}</h3>
                    <span className="h-[22px] w-[22px] min-h-[22px] min-w-[22px] rounded-full border border-white/15 grid place-items-center text-[10px] opacity-60 group-hover:opacity-100 transition shrink-0">↗</span>
                  </div>
                  <p className="mt-1 text-[10px] md:text-[11px] font-medium tracking-wide text-white/45 uppercase truncate">{ch.category}</p>
                </div>
              </button>
            ))}
          </div>
          {filtered.length === 0 && (
            <p className="text-center text-white/50 text-sm py-10">Sin canales en esta categoría.</p>
          )}
        </section>

        {/* RADIO */}
        <section id="radio" className="relative rounded-[24px] md:rounded-[36px] overflow-hidden border border-white/[0.08] mt-2 md:mt-4">
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-[#0e0e0e]" />
            <div
              className="absolute inset-0 opacity-90"
              style={{
                backgroundImage: `radial-gradient(1200px 600px at 70% 20%, rgba(255,26,46,0.18), transparent 60%), radial-gradient(800px 500px at 10% 80%, rgba(124,58,237,0.22), transparent 60%), linear-gradient(to bottom, rgba(0,0,0,0.2), rgba(0,0,0,0.9))`,
              }}
            />
          </div>

          <div className="relative z-10 px-5 sm:px-6 md:px-12 lg:px-16 py-8 md:py-14 lg:py-16">
            <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-5">
              <div>
                <p className="text-[11px] tracking-[0.28em] uppercase text-white/50 font-semibold mb-4 md:mb-6 flex items-center gap-3">
                  <span className="h-px w-8 bg-white/30" />
                  Sintoniza tu día
                </p>
                <p className="text-[12px] md:text-[13px] tracking-[0.22em] uppercase text-white/60 mb-2 md:mb-3 font-medium">El sonido de tu momento</p>
                <h2 className="font-display font-[800] leading-[0.88] tracking-[-0.05em]" style={{ fontSize: 'clamp(38px, 11vw, 78px)' }}>
                  Música
                  <br />
                  sin pausa.
                </h2>
              </div>
              <div className="md:text-right">
                <div className="hidden md:flex items-center md:justify-end gap-3 text-[11px] uppercase tracking-[0.2em] text-white/30 mb-3">
                  <span className="h-2 w-2 rounded-full bg-[#ff1a2e] live-dot" />
                  On air • Ibagué • 24h
                </div>
                <p className="text-[13px] text-white/50 max-w-[340px] leading-relaxed md:ml-auto">Curaduría local. Sin cortes. Directo desde Zeno. Para trabajar, rodar o perderte.</p>
              </div>
            </div>

            {/* Radios: 1 col móvil / 2 tablet / 4 PC */}
            <div className="mt-7 md:mt-10">
              <div className="flex items-center justify-between px-1 pb-3">
                <div className="flex items-center gap-2">
                  <div className="h-7 w-7 rounded-full bg-white grid place-items-center text-black font-black text-[11px]">♫</div>
                  <span className="text-[13px] font-semibold tracking-wide">RADIO • ZENO FM</span>
                </div>
                <span className="text-[11px] text-white/40 tracking-wide">4 señales</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-2.5 md:gap-3">
                {RADIOS.map(r => {
                  const active = playingRadio === r.id && isRadioPlaying;
                  return (
                    <div key={r.id} className={`rounded-[18px] md:rounded-[20px] bg-black/40 backdrop-blur-2xl border border-white/10 p-4 md:p-5 flex flex-col gap-4 ${active ? 'border-white/25 bg-black/60' : ''}`}>
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <span className="h-10 w-10 min-h-[36px] min-w-[36px] rounded-full grid place-items-center text-white font-black text-[13px] shrink-0" style={{ background: r.color }}>{r.id}</span>
                          <div className="min-w-0">
                            <h4 className="text-[14px] font-bold tracking-[-0.01em] truncate">{r.name}</h4>
                            <p className="text-[11px] text-white/45 mt-0.5 truncate">{r.tag}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => toggleRadio(r.id)}
                          className={`h-10 w-10 min-h-[36px] min-w-[36px] rounded-full grid place-items-center border transition-all shrink-0 active:scale-95 ${active ? 'bg-white text-black border-white' : 'bg-white/10 text-white border-white/15 hover:bg-white hover:text-black'}`}
                          aria-label={active ? `Pausar ${r.name}` : `Reproducir ${r.name}`}
                        >
                          {active ? (
                            <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor" aria-hidden="true"><rect x="2" y="2" width="3" height="8" rx="0.5" /><rect x="7" y="2" width="3" height="8" rx="0.5" /></svg>
                          ) : (
                            <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor" className="translate-x-[1px]" aria-hidden="true"><path d="M2.5 1.5 L10 6 L2.5 10.5 Z" /></svg>
                          )}
                        </button>
                      </div>
                      {active ? (
                        <div>
                          <span className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full bg-[#ff1a2e] text-white font-bold"><span className="w-1 h-1 bg-white rounded-full animate-pulse" />LIVE</span>
                          <div className="mt-2.5 h-[2px] w-full bg-white/10 rounded-full overflow-hidden">
                            <div className="h-full bg-white transition-all duration-200" style={{ width: `${progress}%` }} />
                          </div>
                        </div>
                      ) : (
                        <p className="text-[12px] text-white/40 leading-relaxed">Toca play y deja que suene. Sin registro, sin cortes.</p>
                      )}
                    </div>
                  );
                })}
              </div>
              <audio ref={audioRef} className="hidden" />
              <div className="mt-4 flex gap-2">
                <div className="h-9 min-h-[36px] flex-1 rounded-full bg-white/10 border border-white/10 flex items-center px-4 gap-2 text-[12px] text-white/60 truncate">
                  <span className="h-2 w-2 rounded-full bg-white/40 shrink-0" />
                  <span className="truncate">{playingRadio ? `Reproduciendo ${RADIOS.find(r => r.id === playingRadio)?.name}` : 'Selecciona una emisora'}</span>
                </div>
                <button onClick={() => { if (!playingRadio) toggleRadio('01'); else setIsRadioPlaying(v => !v); }} className="h-9 min-h-[36px] px-4 rounded-full bg-white text-black text-[12px] font-bold shrink-0 active:scale-95 transition">Autoplay</button>
              </div>
            </div>
          </div>
        </section>

        <footer className="mt-12 md:mt-24 border-t border-white/10 pt-8 md:pt-10 pb-8 md:pb-16">
          <div className="flex flex-col md:flex-row justify-between gap-8">
            <div>
              <div className="flex items-baseline gap-[2px] mb-3">
                <span className="text-[20px] font-black tracking-[-0.02em] font-display">ibagué</span>
                <span className="text-[11px] font-bold tracking-[0.22em] ml-[5px]">T.Q.M.</span>
              </div>
              <p className="text-[12px] text-white/40 max-w-[360px] leading-relaxed">Clon de interfaz inspirado en la web original. Reinterpretación editorial premium con estética Netflix / Spotify. Reproductores reales provistos por el usuario.</p>
              <div className="mt-5 flex flex-wrap gap-2">
                <span className="px-2.5 py-1 rounded-full bg-white/10 text-[11px] text-white/60">#070707</span>
                <span className="px-2.5 py-1 rounded-full bg-white/10 text-[11px] text-white/60">Space Grotesk • Inter</span>
                <span className="px-2.5 py-1 rounded-full bg-[#ff1a2e]/20 text-[11px] text-[#ff8a94] border border-[#ff1a2e]/20">25 EMBEDS LIVE</span>
              </div>

              <div className="mt-6 rounded-[18px] bg-[#121212] border border-white/10 p-4 max-w-[420px]">
                <p className="text-[10px] tracking-[0.22em] uppercase text-white/40 mb-2 font-semibold">Fuente validada</p>
                <a href="https://ibaguetequiero.lovable.app/" target="_blank" rel="noopener" className="block text-[14px] font-bold leading-tight hover:underline decoration-white/30 underline-offset-4">
                  ibagué T.Q.M. · Televisión y música en vivo
                </a>
                <p className="text-[11px] text-white/40 mt-1">Estructura y curaduría original verificada. Clon con reproductores reales del usuario.</p>
                <a href="https://ibaguetequiero.lovable.app/" target="_blank" rel="noopener" className="mt-3 inline-flex min-h-[36px] items-center gap-2 rounded-full bg-white text-black px-4 py-1.5 text-[12px] font-bold hover:bg-white/90 transition">
                  Abrir fuente oficial ↗
                </a>
              </div>
            </div>

            <div className="md:text-right">
              <div className="inline-flex flex-col items-start md:items-end gap-3 rounded-[18px] bg-[#121212] border border-white/10 p-4 w-full md:min-w-[280px] md:w-auto">
                <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.2em] text-white/40"><span className="h-px w-6 bg-white/20" /> Enlaces</div>
                <a href="https://ibaguetequiero.lovable.app/" target="_blank" rel="noopener" className="text-[14px] font-bold leading-tight hover:underline decoration-white/30 underline-offset-4 text-left md:text-right">
                  ibagué T.Q.M. · Televisión y música en vivo
                </a>
                <a href="https://ibaguetequiero.lovable.app/" target="_blank" rel="noopener" className="inline-flex min-h-[36px] items-center gap-2 rounded-full bg-white text-black px-4 py-1.5 text-[12px] font-bold hover:bg-white/90 transition">
                  Visitar web original ↗
                </a>
                <p className="text-[11px] text-white/35 mt-1">Clon con fines demostrativos. Todos los logos pertenecen a sus dueños.</p>
              </div>
              <div className="mt-6 text-[11px] text-white/25">© 2025 ibagué T.Q.M. clon • Hecho en Ibagué • #070707</div>
            </div>
          </div>
        </footer>
      </main>

      {/* BOTTOM BAR FIJA — SOLO MÓVIL */}
      <nav
        aria-label="Filtros rápidos"
        className="fixed bottom-0 inset-x-0 z-40 md:hidden border-t border-white/10 backdrop-blur-2xl"
        style={{ background: 'rgba(7,7,7,0.92)', paddingBottom: 'env(safe-area-inset-bottom)' }}
      >
        <div className="flex items-center gap-2 px-3 pt-2 pb-2">
          {QUICK_FILTERS.map(cat => (
            <button
              key={cat}
              onClick={() => goToChannels(cat)}
              className={`flex-1 min-h-[36px] rounded-full text-[12px] font-semibold transition active:scale-95 ${
                activeCat === cat ? 'bg-white text-black' : 'bg-white/10 text-white/75'
              }`}
            >
              {cat}
            </button>
          ))}
          <button
            onClick={goTop}
            className="min-h-[36px] min-w-[44px] px-3 rounded-full bg-[#ff1a2e] text-white text-[12px] font-bold active:scale-95 transition flex items-center justify-center gap-1"
            aria-label="Volver arriba"
          >
            ↑ Arriba
          </button>
        </div>
      </nav>

      {/* MODAL: fullscreen móvil 100dvh / centrado PC */}
      {showModal && selected && (
        <div className="fixed inset-0 z-[100] flex items-stretch md:items-center justify-center md:p-6">
          <div className="absolute inset-0 bg-black/90 backdrop-blur-xl" onClick={closeModal} />
          <div className="relative w-full h-[100dvh] md:h-auto md:max-w-[1000px] md:rounded-[22px] overflow-hidden bg-[#121212] md:border md:border-white/15 shadow-[0_24px_80px_rgba(0,0,0,0.8)] animate-[in_0.28s_cubic-bezier(0.16,1,0.3,1)] flex flex-col">
            <style>{`@keyframes in { from { opacity:0; transform: translateY(14px) scale(0.98);} to { opacity:1; transform: translateY(0) scale(1);} }`}</style>
            <div className="flex items-center justify-between px-4 md:px-7 min-h-[56px] border-b border-white/10 bg-white/[0.03] shrink-0">
              <div className="flex items-center gap-3 min-w-0">
                <div className={`h-9 w-9 min-h-[36px] min-w-[36px] rounded-full bg-gradient-to-br ${selected.gradient} grid place-items-center text-[10px] font-black shrink-0`}>{selected.initials.slice(0, 2)}</div>
                <div className="min-w-0">
                  <h3 className="text-[14px] font-bold leading-none truncate font-display">{selected.name}</h3>
                  <p className="text-[11px] text-white/50 mt-1 truncate">{selected.category} • En vivo • {(() => { try { return new URL(selected.embedUrl).hostname } catch { return 'player' }})()}</p>
                </div>
                <span className="ml-1 hidden sm:inline-flex items-center gap-1.5 rounded-full bg-[#ff1a2e] px-2 py-0.5 text-[10px] font-bold text-white shrink-0">
                  <span className="w-1 h-1 bg-white rounded-full animate-pulse" /> EN VIVO
                </span>
              </div>
              <button onClick={closeModal} className="h-9 w-9 min-h-[36px] min-w-[36px] rounded-full bg-white/10 hover:bg-white/15 grid place-items-center text-white/70 hover:text-white transition shrink-0 ml-2 active:scale-95" aria-label="Cerrar">
                <svg width="14" height="14" viewBox="0 0 14 14" stroke="currentColor" strokeWidth="1.5" fill="none"><path d="M3 3 L11 11 M11 3 L3 11" /></svg>
              </button>
            </div>

            <div className="relative bg-black flex-1 md:flex-none md:aspect-[16/9] w-full overflow-hidden min-h-0">
              <iframe
                key={selected.id}
                src={selected.embedUrl}
                title={selected.name}
                className="absolute inset-0 w-full h-full"
                frameBorder="0"
                scrolling="no"
                allowFullScreen
                allow="autoplay; encrypted-media"
                loading="lazy"
              />
            </div>

            <div className="px-4 md:px-7 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-[#151515] border-t border-white/10 shrink-0" style={{ paddingBottom: 'calc(14px + env(safe-area-inset-bottom))' }}>
              <p className="text-[12px] text-white/40">
                Estás viendo <span className="text-white/80 font-medium">{selected.name}</span> • Si el reproductor no carga, abre en pestaña nueva.
              </p>
              <div className="flex items-center gap-2">
                <a href={selected.embedUrl} target="_blank" rel="noopener" className="h-9 min-h-[36px] px-3 rounded-full bg-white/10 text-[12px] text-white/70 hover:bg-white/15 inline-flex items-center">Abrir fuente ↗</a>
                <button onClick={closeModal} className="h-9 min-h-[36px] px-4 rounded-full bg-white text-black text-[12px] font-bold">Cerrar</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
